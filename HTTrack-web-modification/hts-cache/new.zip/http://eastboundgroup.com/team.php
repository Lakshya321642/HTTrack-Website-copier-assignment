<!DOCTYPE HTML>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group |Team</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>    <!-- HEADER -->
    <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    <div class="clearfix"></div>
    <!-- /SLIDE --> 
	</div>
	</div>
	</div>
	</div>
	</div>
	<div class="section-team margin-top-100">
		<div class="container">
			<div class="section-title title-style5 text-center">
			</div>
    
            <div style="width:100%;">
            <h1 class="text-center blue-heading2">OUR <font class="red-heading1">FOUNDERS</font></h1>
        <div class="container">
            <div class="row padding-top50 margin-bootom-30">
                <div class="col-sm-4 center-block">
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <img alt="" src="images/team/P.png"/>
                        <center><h6 style="color:#000; padding-top: 30px;">PRRITHVIRAJ</h6></center>
                    </div>
                 
                    
                  <div class="content-post">
                            <p><center>Prrithviraj has spent over three decades with his first love - the travel and tourism industry. He connects natively with the ethos of the sub-continent and is deeply rooted in its culture both on a personal and professional level. He has been visionary in driving the company’s presence into new sectors, including CHIME (Conference & Events), and BYOND (Online travel portal), 2HUB, among others.</center>
                              </p>
                        </div>
                </article>
                </div>
                
                <div class="col-sm-4 center-block">
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <img alt="" src="images/team/team.png"/>
                        <center><h6 style="color:#000; padding-top: 30px;">MANISH PRATIK</h6></center>
                    </div>
                    
                  <div class="content-post">
                            <p><center>Manish is well known as an innovator embracing new challenges to create destinations little known to the outside world. With his career of over two decades, he enjoys a formidable reputation in the travel fraternity. Being tech-savvy, he always encourages innovative ways to integrate technology to break silos and modernise the DMC business processes at Eastbound. He also drives EB’s ‘Go Green’ resort project, Orchard.</center>
                                        </p>
                                       </div>
                </article>
                </div>
                
                <div class="col-sm-4 center-block">
                    <article class="blog-item style5 blog-item-masonry">
                    <div class="post-format">
                        <img alt="" src="images/team/AK.png">
                        <center><h6 style="color:#000; padding-top: 30px;">AMIT KISHORE</h6></center>
                    </div>
                 
                    
                  <div class="content-post">
                            <p><center>Career entrepreneur, investor and co-founder of some of the premier travel companies, Amit leads the growth strategy for the Eastbound Group in India and globally. He has successfully developed high-value partnerships with International Tour Operators to grow their business in Indian Subcontinent and the UAE. He is also on the board of several companies and is an advisor to the tourism boards of Taiwan, Jordan, Maldives and Yas Island -  Abu Dhabi.</center>
                                     </p>
                        </div>
                </article>
                </div>
            </div>
        </div>
    </div>
    
                
       <div class="section-testimonial base6">
        
        <div class="container padding-top50">
           <h1 class="text-center blue-heading2">INDIA <font class="red-heading1">SPECIALISTS</font></h1>
            <div class="">
                <div class="testimonials testimonials-style3 owl-carousel navigation-center-center padding-top50" data-nav="true" data-dots="false" data-items="1" data-autoplay="true" data-loop="true">
                    <div class="testimonial">
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/RESHMA.jpg" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">RESHMA NAQVI</h6>
                                <p>An evolved traveller, drifter, and dreamer, she is happiest when her backpack is full and horizons are open.</p>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                               <img src="images/team/RL.png" alt="" />
                            </div>                   
                            <div class="inner">
                                <h6 style="color:#000;">RADHIKA LAL</h6>
                                    <p>In-bound Specialist, 20-years,<br> Experience with the biggest names,<br> Excellent vendor management</p>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/ichcha.jpg" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">ICHCHA DHUPIA</h6>
                                <p>Over two decades in Travel, Ichcha hopes to continue being able to make travel dreams come true through stellar service and outstanding planning.</p>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/Rohit.png" alt="" />
                            </div>                   
                            <div class="inner">
                                <h6 style="color:#000;">ROHIT GUPTA</h6>
                                <p>Educational Travel Whiz, Powerhouse Energy,<br> Ability to make people meet,<br> socialize and work cross-culturally</p>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/a.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">PRAVIN BHHARDWAJ</h6>
                                    <p>Contracting Pro, Travel Industry Veteran,<br> Sharp Networking skills, <br>Operational Genius & Quality Control</p>
                            </div>
                        </div>
                            <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/Swati.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">SWATI CHANDRA</h6>
                                    <p>Culturally Sensitive, Gourmand,<br> Ace Supervisior, Passionate,<br> Motorbiker, Seasoned Travel Expert</p>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial">
                            <div class="col-sm-12 col-md-4">
                                <div class="avatar">
                                    <img src="images/team/dipta.png" alt="" />
                                </div>                   
                                <div class="inner">
                                    <h6 style="color:#000;">DIPTA ROY</h6>
                                    <p>A very old hand in the trade, with 15 years of experience curating unique & experiential travel journeys. <!--A well-travelled young professional, an aspiring artist and a big foodie, he wears multiple hats and it also reflects in his multi-tasking ability at work.--></p>
                                </div>
                            </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/rajesh.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">RAJESH KUMAR</h6>
                                <p>Rajesh has an immense love for travel, and you can see him immersed with travel thoughts and experiences to talk about.</p>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/Ishwar.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">ISHWAR SINGH</h6>
                                <p>The deep knowledge of destinations and understanding of clients' needs make Ishwar an asset to the organisation.</p>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial">
                        <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/Binay.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">BINAY GUPTA</h6>
                                <p>Applauded as the "people's person," Binay is an avid traveller, a storyteller, and a perfectionist by nature.</p>
                            </div>
                        </div>
                            
                            <div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/Abhishek.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">ABHISHEK HAJELA</h6>
                                <p>Travel Photographer, Nikon Award winner,<br> Olympus brand ambassador,<br> Product Specialist</p>
                            </div>
                        </div>
                       <!--<div class="col-sm-12 col-md-4">
                            <div class="avatar">
                                <img src="images/team/rajesh.png" alt="" />
                            </div>
                            <div class="inner">
                                <h6 style="color:#000;">RAJESH KUMAR</h6>
                                <p>Rajesh has an immense love for travel, and you can see him immersed with travel thoughts and experiences to talk about.</p>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="">
        
            <div class="section-title text-center">
               
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/4.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/5.jpg"  class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/6.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/7.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
            </div>
       
    </div>
   
    <div class="section-testimonial base6">
        <div class="title-page-section">
            <div class="container padding-top50">
                 <h1 class="text-center blue-heading2">SRILANKA <font class="red-heading1">SPECIALISTS</font></h1>
            </div>
        </div>
        <div class="container padding-top50">
            <div class="testimonials testimonials-style2">
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="avatar">
                             <img src="http://eastboundgroup.com/images/team/wa.png" alt="" />
                        </div>
                      <div class="inner text-center">
                         <h6 style="color:#000;">MS. WYOMI ABHAYARATNE</h6>
                            <p>Wyomi has extensive travel knowledge <br>and is one of the most experienced<br> tourism professionals in Sri Lanka.</p>
                            
                        </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
    
    

        
            <div class="section-title text-center">
               
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/8.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/9.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/10.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/11.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
            </div>
            
            
            <div class="section-testimonial base6">
        <div class="title-page-section">
            <div class="container padding-top50">
                 <h1 class="text-center blue-heading2">NEPAL <font class="red-heading1">SPECIALISTS</font></h1>
            </div>
        </div>
        <div class="container padding-top50">
            <div class="testimonials testimonials-style2">
                <div class="row">
                    <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                             <img src="images/team/ns-1.jpg" alt="" />
                        </div>
                      <div class="inner text-center">
                         <h6 style="color:#000;">BIJAY NEPAL</h6>
                            <p>Extensive national and international experience in the tourism industry for the last 27 years, practically evolved with all four pillars of tourism- travel, trekking, hotel, and aviation.</p>
                        </div>
                        </div>
                    <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                              <img src="images/team/ns-2.jpg" alt="" />
                        </div>
                       <div class="inner text-center">
                         <h6 style="color:#000;">BIJAY POUDEL</h6>
                            <p>Masters in Business Administration. He was a director – at Hotel Royal Image Pokhara in 2010. Later, he also entered the travel and trekking business. He has got deep knowledge of touristic destinations in Nepal.</p>
                        </div>
                        </div>
                        <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                              <img src="images/team/ns-3.jpg" alt="" />
                        </div>
                       <div class="inner text-center">
                         <h6 style="color:#000;">DILIP SHAMSHER KUNWAR </h6>
                            <p>Started a career in Nepalese Tourism in 2005 and is an expert in building good relations with trade suppliers and designing tour packages with the best prices.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   
    <div class="section-title text-center">
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/12.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/13.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/14.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/15.jpg" class=" center-block" alt="" />
                        </div>
                    </div>
                </div>
            </div>
            
            
            
   
     <div class="section-testimonial base6">
        <div class="title-page-section">
            <div class="container padding-top50">
                 <h1 class="text-center blue-heading2">UAE <font class="red-heading1">SPECIALISTS</font></h1>
            </div>
        </div>
        <div class="container padding-top50">
            <div class="testimonials testimonials-style2">
                <div class="row">
                    <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                             <img src="images/team/us-2.jpg" alt="" />
                        </div>
                      <div class="inner text-center">
                         <h6 style="color:#000;">ASIT KUMAR</h6>
                            <p>20-year experience in the travel industry, competitive rates, service standards, and foodie with deep knowledge of traditions and culture.</p>
                        </div>
                        </div>

                        <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                              <img src="images/team/Aniket.png" alt="" />
                        </div>
                       <div class="inner text-center">
                         <h6 style="color:#000;">ANIKET DAS</h6>
                            <p>Love to meet new people and explore new places, history enthusiast and admirer of various cultures, enhances traveller’s experience, and always goes the extra mile to create value.</p>
                        </div>
                        </div>

                        <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                              <img src="images/team/Aman.png" alt="" />
                        </div>
                       <div class="inner text-center">
                         <h6 style="color:#000;">AMANDEEP SINGH</h6>
                            <p>More than 20 years of travel experience, passionate about innovating and offering unique experiences, loves to listen to music and a gadget freak.</p>
                        </div>
                        </div>
                 
                  
                    <!--<div class="col-sm-12 col-md-4">
                        <div class="avatar">
                              <img src="images/team/us-3.jpg" alt="" />
                        </div>
                       <div class="inner text-center">
                         <h6 style="color:#000;">YASH HAJELA</h6>
                            <p>Technology enthusiast,<br>seamless customer handling,<br>service-oriented</p>
                        </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-4">
                        <div class="avatar">
                              <img src="images/team/us-4.jpg" alt="" />
                        </div>
                       <div class="inner text-center">
                         <h6 style="color:#000;">JIGNESH PATEL </h6>
                            <p>Cook and singer par excellence,<br> he loves to meet people<br> and immerse them in<br> new and rich experiences  </p>
                        </div>
                        </div>-->
                        
                        
                        
                </div>
            </div>
        </div>
    </div>
	
	
	
	

    
    
      <div class="section-title text-center">
               
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/16.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/17.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/18.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/19.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
            </div>
            

    
    <div class="section-testimonial base6">
        <div class="title-page-section">
            <div class="container padding-top50">
                 <h1 class="text-center blue-heading2">BHUTAN <font class="red-heading1">SPECIALISTS</font></h1>
            </div>
        </div>
        <div class="container padding-top50">
            <div class="testimonials testimonials-style2">
                <div class="row">
                       
                        <div class="col-sm-12 col-md-12">
                        <div class="avatar">
                             <img src="images/team/Deepsika.jpeg" alt="" />
                        </div>
                      <div class="inner text-center">
                         <h6 style="color:#000;">DEEPSIKA RAI</h6>
                            <p>Deepsika is an Arts graduate with an experience of more than eight years in operations, handling various groups and most discerning travelers from all over the world.</p>
                            
                        </div>
                        </div>
                        
                        
                 
                  
                    
                </div>
            </div>
        </div>
    </div>
   
   
   
    <div class="section-title text-center">
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/20.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/21.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/22.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="team team-style4">
                        <div class="team-image">
                            <img src="images/team/23.jpg" class=" center-block" alt="" />
                        </div>
                        
                    </div>
                </div>
            </div>
            

			
<!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>
</html>