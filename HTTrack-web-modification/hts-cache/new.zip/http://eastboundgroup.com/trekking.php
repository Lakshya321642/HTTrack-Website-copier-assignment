<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Treking</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
    <link href="css/jquery.littlelightbox.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/photography-slider.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
 
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body> 
<aside id="sticky-social">
    <ul>
       <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
      <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
      <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
      <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="margin-top-100 margin-top-50">
		<div class="container">
			<div class="about-text text-center">
			
				<p class="black-heading1" style="font-weight:200; font-size:36px">Trekking</p>
               
			</div>
			
		</div>
	</div>
    

        <div class="container margin-top-30">
            <div class="col-sm-12 col-md-12 main-content pt-slider-bg">
                <div class="w3-content w3-display-container">

<a class="w3-btn-floating w3-hover-dark-grey w3-display-left" onClick="plusDivs(-1)">&#10094;</a>
<a class="w3-btn-floating w3-hover-dark-grey w3-display-right" onClick="plusDivs(1)">&#10095;</a>

<div class="w3-display-container mySlides">
  <img src="images/photography-tours/slide-4.jpg" style="width:100%">
</div>

<div class="w3-display-container mySlides">
  <img src="images/photography-tours/slide-5.jpg" style="width:100%">
</div>

</div>
            </div>
            
        </div>
        
        
      <script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel,4000); // Change image every 2 seconds
}
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  x[slideIndex-1].style.display = "block"; 
   
}
</script>

   
   
   
   
   
   
   <div class="section-about">
		<div class="container">
            <div class="col-sm-12 col-md-12 main-content">
                <div class="blog-single">
                    
                    <div class="related-posts">
                       
                        <div class="list-related-posts">
                            <article class="blog-item row">
                                <div class="col-sm-4">
                                    <div class="post-format">
                                      <img src="images/photography-tours/Walking.jpg" style="margin-top:11px;" alt="" /></a>                                    </div>
                              </div>
                                <div class="col-sm-8">
                                    <div class="content-post">
                                     <p><font class="yellow-color"><strong>There are many hidden places</strong></font> in India that cannot be reached by car, train, bus or any other means of transport. In such cases, your own two legs – the natural means of transport – can take you forward. Every bit of land is accessible by this means in the most fuel-efficient manner.</p>
									 <p>Most of the treks delve deep into nature with the rivers, flowers, birds, animals, lush green trees, forts, caves, waterfalls, etc. There’s ceaseless amazement at what mother nature might present to you. Last but not the least, pure air, which is a luxury nowadays for those of us who reside in concrete city jungles.</p>

<p>Highlights: </p>

<div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Trekking in search of the ghost cat.</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                    
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Climb to Nako which is famous for it’s sacred waterbody ‘Nako Lake’ and 1000 yrs old Monastery. </p>
					</div>       
                     <div class="clearfix"></div> 
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Explore the local Monastery of the village.</p>
					</div>
                     <div class="clearfix"></div> 
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Trek to the beautiful village of Langza , also known as The Fossil Village.</p>
					</div>
                     <div class="clearfix"></div> 
                    
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Trek down to the lone lake ‘Chandra Tal’ aka ‘The Lake of the Moon’ to enjoy a lovely picnic</p>
					</div>
                     <div class="clearfix"></div> 

                                    </div>
                                  
                                </div>
                            </article>
                           
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
	</div>
   
  <script src="js/photography-tours.js"></script>
<script src="js/jquery.littlelightbox.js"></script>
<script>
$('.lightbox').littleLightBox();
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
   
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>