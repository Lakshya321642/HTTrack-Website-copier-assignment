

<!DOCTYPE HTML>
<html>
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta charset="UTF-8">
      <meta name="author" content="ngocthang.ict" />
      <title>Eastbound Group | Eastnews</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
      <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
      <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
      <link rel="stylesheet" type="text/css" href="css/chosen.css" />
      <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
      <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
      <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
      <link rel="stylesheet" type="text/css" href="css/animate.css" />
      <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
      <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
      <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
      <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
      <script type="text/javascript" src="js/popup1.js"></script>
      <script type="text/javascript" src="js/popup2.js"></script>
      <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
      <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
      <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
      <link rel="stylesheet" type="text/css" href="css/style.css" />
   </head>
   <body>
      <aside id="sticky-social">
         <ul>
            <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="https://plus.google.com/100809616177764073302?hl=en" class="entypo-gplus" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="http://eastboundgroup.com/csr.php" class="entypo-linkedin" target="_blank"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
         </ul>
      </aside>
      <!-- HEADER -->
          <!-- HEADER -->
    <header class="header header-fullwidth base-inner1" >
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
                <a href="index.php"><img src="images/logo.png" alt="" /></a>
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a href="http://eastboundgroup.com/index.php" target="_blank">Home</a>                    </li>
						<li>
                        <a href="eastnews.php" target="_blank">Newsletter</a>                        </li>
					<li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>
                        </ul>
					</li>
<li>
                        <a href="http://eastboundgroup.com/destinations.php" target="_blank">Destinations</a>                    </li>
<li>
                        <a href="http://eastboundgroup.com/services.php" target="_blank">Services</a>                  </li>
<li>
                        <a href="http://eastboundgroup.com/csr.php" target="_blank">CSR</a>                    </li>
                        <li>
                        <a href="#" target="_blank">Payment Policies</a>                   </li>
<li class="menu-item-has-children">
                        <a href="http://eastboundgroup.com/contact-us.php" target="_blank">Contact</a>                   </li>
                    
                    
                    
              </ul>
            </nav>
            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
            </header>
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE -->   
      <!-- ./HEADER -->
      <!-- SLIDE -->
      <div class="clearfix"></div>
      <!-- /SLIDE --> 
      <div class="section-about margin-top-100">
         <div class="container">
            <div class="about-text text-center">
               <h1 class=" black-heading1">Eastnews</h1>
               <h5 class="text-center black-heading1">Product updates, activities, festivals and all that’s new from the sub-continent...</h5>
               <br>
               <h4 class="black-heading1"><a href="subscription.php" target="_blank"><strong><font color="#015095">"CLICK HERE"</font></strong></a> to subscribe our monthly newsletter and keep updated with latest news & Trends from travel industry.</h4>
            </div>
         </div>
      </div>
      <div class="section-about base5">
         <div class="container">
            <!-- Blog maroonry -->
            <div id="blog-masonry" class="blog-masonry padding-top40" data-cols="3">
			<article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/61.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">May 2023</h4>
                  <div class="content-post">
                     <p class="text-center">Project Tiger <br> India's 50 Year Conservation Success story</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2023/May/NL1/EB-Newsletter-May-2023.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
			
				  <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/60.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">April 2023</h4>
                  <div class="content-post">
                     <p class="text-center">luxury and Wellness <br> The Best Spa Resorts in India</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2023/April/NL1/EB-Newsletter-April-2023.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
				  <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/59.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">March 2023</h4>
                  <div class="content-post">
                     <p class="text-center">Eastbound Connect Series<br> Chapter - 2</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2023/March/NL1/EB-March.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
			<article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/58.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">February 2023</h4>
                  <div class="content-post">
                     <p class="text-center">India - In <br> All Its Glory</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2023/February/NL1/EB-Newsletter-February-2023.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
				  <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/57.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">January 2023</h4>
                  <div class="content-post">
                     <p class="text-center">The Epitome of Diversity<br> History, Culture, Art & Tradition</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2023/NL1/EB-Newsletter-January-2023.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
			<article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/56.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">December 2022</h4>
                  <div class="content-post">
                     <p class="text-center">Fall in Love<br> With shri Lanka Again</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/December/NL/EB-Newsletter-December-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
				  <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/55.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">November 2022</h4>
                  <div class="content-post">
                     <p class="text-center">The Hornbill Festival<br> Makes a Come Back This Year</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/November/EB-Newsletter-November-2022--(1).html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
			<article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/54.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">October 2022</h4>
                  <div class="content-post">
                     <p class="text-center">The Cheetah Makes<br> a Glorious comeback</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/October/NL1/EB-Newsletter-October-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
				  </article>
			<article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/53.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">September 2022</h4>
                  <div class="content-post">
                     <p class="text-center">Indian's Hottest  <br> New Hotels</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/September/NL1/EB-Newsletter-September-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
			<article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/52.gif"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">August 2022</h4>
                  <div class="content-post">
                     <p class="text-center">The Postcard Mandalay <br> Hall, Cochin</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/August/NL1/EB-Newsletter-August-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
			   <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/51.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">July 2022</h4>
                  <div class="content-post">
                     <p class="text-center">Despite Challenges, Sri Lanka  <br> Continues To Welcome Tourists</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/July/EB-Newsletter-July-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
			 <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/50.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">June 2022</h4>
                  <div class="content-post">
                     <p class="text-center">The First Fly in Resort<br> With Private Charters</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/June/NL1/EB-Newsletter-June-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
			 <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/49.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">May 2022</h4>
                  <div class="content-post">
                     <p class="text-center">The Very First<br> Six Senses Property in Inida</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews/2022/May/NL1/EB-Newsletter-may-2022.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/48.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">August 2020</h4>
                  <div class="content-post">
                     <p class="text-center">The Wild Sri Lanak<br> Explore the Unknown</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/August/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>			
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/47.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">July 2020</h4>
                  <div class="content-post">
                     <p class="text-center">Secluded<br> Luxury Hideaways</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/July/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>			
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/46.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">June 2020</h4>
                  <div class="content-post">
                     <p class="text-center">Luxury<br> Spa Resorts</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/June/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/45.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">May 2020</h4>
                  <div class="content-post">
                     <p class="text-center">Ayurveda<br>A necessity of life</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/May/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/44.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">April 2020</h4>
                  <div class="content-post">
                     <p class="text-center">Bhisti<br>A tribe to remember</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/April/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/43.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">March 2020</h4>
                  <div class="content-post">
                     <p class="text-center">New Summer Hotspots<br>Northernmost India</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/March/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/42.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">February 2020</h4>
                  <div class="content-post">
                     <p class="text-center">Pannigarans of Jaipur<br>Creating masterpieces in the shadows</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/February/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/41.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">January 2020</h4>
                  <div class="content-post">
                     <p class="text-center">Nocturnal Experiences:<br>India rediscovered after 7 pm</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2020/January/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/40.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">December 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Future of India’s<br>Inbound Tourism </p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/December/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/39.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">November 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Sri Lanka After 41 years and the civil war,<br> Jaffna airport welcomes first flight from Tamil Nadu</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/November/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/38.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">October 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Bengal 2.0<br> Rediscovering “The Sweetest Part of India”</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/October/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/37.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">September 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Eastbound Office<br> Now in Vietnam</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/September/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/36.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">August 2019</h4>
                  <div class="content-post">
                     <p class="text-center">EB Volun‘tourism’ Programme<br> A combination of Volunteering and Tourism</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/August/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/35.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">July 2019</h4>
                  <div class="content-post">
                     <p class="text-center">A Rare Event, Once in 40 Year<br> Athi Varadhar Vaibhav, 2019.</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/July/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/34.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">June 2019</h4>
                  <div class="content-post">
                     <p class="text-center">The Elusive Indian Wolf<br> The Unseen Predator</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/June/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/33.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">April 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Down the river, into the wild<br> Dense forest and flowing river come together at Quiet by the River, the secluded riverside lodge in Malayattoor</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/april/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/32.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">March 2019</h4>
                  <div class="content-post">
                     <p class="text-center">we are proud to introduce<br> our new division Eastbound Outdoors</p>
                     <br><br>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/March/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/31.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">February 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Visit Nepal 2020<br> The hottest destination around the world!</p>
                  <br><br></div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/February/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/30.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">January 2019</h4>
                  <div class="content-post">
                     <p class="text-center">Orchard Resort, Pushkar<br> Live in the lap of Nature, Luxury Tents</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2019/January/index1.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/29.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">November 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Diwali Celebration at EB Office<br> Going green & NO to fire crackers.</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/November/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/28.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">October 2018</h4>
                  <div class="content-post">
                     <p class="text-center">8 Days Desert Ride, Rajasthan<br> The best of the magical Marwar Kingdom.</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/October/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/27.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">September 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Mysore Style of Yoga: First Hand experience of how<br> yoga has change the perspective towards life.</p>
                  <br></div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/September/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/26.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">August 2018</h4>
                  <div class="content-post">
                     <p class="text-center">The Gods Own Country<br>On a path towards a speedy recovey!</p>
                  <br></div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/August/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/25.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">July 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Ladakh Travelogue by Rahul Brijnath<br>A honest story of a globe trotter returning to the splendor of Ladakh after 30 Years!!</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/July/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/24.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">June 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Queen of hills Munnar will be painted Blue<br>Experience a rare occurrence with EB</p>
                     
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/June/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/23.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">May 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Refocusing Bandhavgarh through the lenses<br>A personalised experience by Abhishek Hajela</p>
                     
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/May/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/22.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">April 2018</h4>
                  <div class="content-post">
                     <p class="text-center">The Beautiful North East, India <br>Photo Chronicle</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/April/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/21.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">March 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Visit Kumbh Mela in 2019 <br>The largest peaceful gathering in the world!</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/March/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/20.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">February 2018</h4>
                  <div class="content-post">
                     <p class="text-center">Srilanka <br>A Photo Essay by Abhishek</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/February/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/19.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">January 2018</h4>
                  <div class="content-post">
                     <p class="text-center">The Hidden Gem <br>Uncovered</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2018/January/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/18.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">November 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Anoothi Vishal <br>Columnist & Food Writer</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/November/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/17.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">October 2017</h4>
                  <div class="content-post">
                     <p class="text-center">India’s First <br>Cherry Blossomm Festival</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/October/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/16.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">September 2017</h4>
                  <div class="content-post">
                     <p class="text-center">...and the <br>Festivities Begins!</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/September/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/15.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">August 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Bescope Cycling<br>Himalayas and beyond!</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/August/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/14.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">July 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Photo Essay: Puri Rath Yatra<br>By Abhishek Hajela</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/July/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/13.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">June 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Welcome India’s Monsoon<br>with the wild ones</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/June/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/12.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">May 2017</h4>
                  <div class="content-post">
                     <p class="text-center">The pink city of Jaipur<br>has more to offer for the 
                        new-age food lovers
                     </p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/may/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/11.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">April 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Summer Specials <br> By EB Group</p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/apr/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/10.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">March 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Hotels Handpicked <br>
                        By EB Team
                     </p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/mar/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/9.jpg"/></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">February 2017</h4>
                  <div class="content-post">
                     <p class="text-center">Hotel Review: Firsthand <br>  experiences by senior EB staff </p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/feb/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/8.jpg"/></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">January 2017</h4>
                  <div class="content-post">
                     <p class="text-center">The Festival of India<br> List of Indian Festivals </p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2017/jan/newsletter/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/7.jpg"/></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">December 2016</h4>
                  <div class="content-post">
                     <p class="text-center">Srilanka Special: Our 3<br> Handpicked Hotels for you </p>
                  </div>
                  <center>     <a href="http://eastboundgroup.com/eastnews-newsletter/2016/dec/newsletter/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/6.jpg"/></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">September 2016</h4>
                  <div class="content-post">
                     <p class="text-center">An Insider Guide to some of India’s<br> finest charming home-stays </p>
                  </div>
                  <center>     <a href="http://eastbound.in/PU/Sep16/" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/5.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">June 2016</h4>
                  <div class="content-post">
                     <p class="text-center">The festival of India</p>
                     <br>
                  </div>
                  <center>     <a href="http://eastbound.in/PU/June16/festivals.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/4.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">May 2016</h4>
                  <div class="content-post">
                     <p class="text-center">Where & what to eat in India<br> this season...</p>
                  </div>
                  <center>     <a href="http://eastbound.in/PU/may2016/index.html" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/3.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">February 2016</h4>
                  <div class="content-post">
                     <p class="text-center">Flight of The Hornbill</p>
                     <br>
                  </div>
                  <center>     <a href="http://eastbound.in/PU/Feb2016/PUfeb.pdf" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/2.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">December 2015</h4>
                  <div class="content-post">
                     <p class="text-center">Merry Christmas</p>
                     <br>
                  </div>
                  <center>     <a href="http://eastbound.in/PU/Dec15/DecPU.pdf" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
               <article class="blog-item style5 blog-item-masonry">
                  <div class="post-format">
                     <figure><img alt="" class="center-block en-border" src="http://eastboundgroup.com/images/eastnews/1.jpg"></figure>
                  </div>
                  <h4 class="blog-title yellow-color text-center padding-top10">August 2015</h4>
                  <div class="content-post">
                     <p class="text-center">Madras Music Festival</p>
                  </div>
                  <center>     <a href="http://eastbound.in/PU/August15/doc1.html#link1" target="_blank"><b>CLICK TO VIEW </b> </a>
                  </center>
                  <br><br>
               </article>
            </div>
            <!-- ./Blog maroonry -->
         </div>
         <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog modal-md">
               <div class="modal-content my-model">
                  <div class="modal-header my-header">
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                     <h3 class="modal-title">Please Fill Your Details To Download File.</h3>
                  </div>
                  <div class="modal-body">
                     <form>
                        <div class="form-group-model">
                           <input type="text" class="form-control" name="name" id="usr" placeholder="Name" required>
                        </div>
                        <div class="form-group-model">
                           <input type="text" class="form-control" name="eamil" id="usr" placeholder="Email Address" required>
                        </div>
                        <div class="form-group-model">
                           <input type="text" class="form-control" name="phone" id="usr" placeholder="Mobile Number" required>
                        </div>
                        <input type="submit" class="btn btn-lg btn-block btn-primary my-primary" value="Submit">
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- FOOTER -->
      <footer class="footer">
         <div class="footer-bottom">
            <div class="container">
               <div class="row">
                  <div class="col-sm-5">
                     <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                  </div>
                  <div class="col-sm-7">
                     <ul class="footer-menu">
                        <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="http://eastboundgroup.com/csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
      <!-- ./FOOTER -->
      <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>
      <script type="text/javascript" src="js/owl.carousel.min.js"></script>
      <script type="text/javascript" src="js/chosen.jquery.min.js"></script>
      <script type="text/javascript" src="js/Modernizr.js"></script>
      <script type="text/javascript" src="js/jquery.countTo.js"></script>
      <script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
      <script type="text/javascript" src="js/jquery.easing.min.js"></script>
      <script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
      <script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
      <script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
      <script type="text/javascript" src="js/lightbox.min.js"></script>
      <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
      <script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
      <script type="text/javascript" src="js/jquery.countdown.min.js"></script>
      <script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
      <script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
      <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
      <script type="text/javascript" src="js/portfolio.js"></script>
      <script type="text/javascript" src="js/blog-masonry.js"></script>
      <script type="text/javascript" src="js/masonry.js"></script>
      <script type="text/javascript" src="js/custom.js"></script>
   </body>
</html>

