<!DOCTYPE HTML>
<html>
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta charset="UTF-8">
      <meta name="author" content="ngocthang.ict" />
      <title>Eastbound Group | Eastnews</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
      <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
      <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
      <link rel="stylesheet" type="text/css" href="css/chosen.css" />
      <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
      <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
      <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
      <link rel="stylesheet" type="text/css" href="css/animate.css" />
      <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
      <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
      <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
      <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
      <script type="text/javascript" src="js/popup1.js"></script>
      <script type="text/javascript" src="js/popup2.js"></script>
      <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
      <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
      <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
      <link rel="stylesheet" type="text/css" href="css/style.css" />
   </head>
   <body>
      <aside id="sticky-social">
         <ul>
            <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="https://plus.google.com/100809616177764073302?hl=en" class="entypo-gplus" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="http://eastboundgroup.com/csr.php" class="entypo-linkedin" target="_blank"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
         </ul>
      </aside>
      <!-- HEADER -->
          <!-- HEADER -->
    <header class="header header-fullwidth base-inner1" >
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
                <a href="index.php"><img src="images/logo.png" alt="" /></a>
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a href="http://eastboundgroup.com/index.php" target="_blank">Home</a>                    </li>
						<li>
                        <a href="eastnews.php" target="_blank">Newsletter</a>                        </li>
					<li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>
                        </ul>
					</li>
<li>
                        <a href="http://eastboundgroup.com/destinations.php" target="_blank">Destinations</a>                    </li>
<li>
                        <a href="http://eastboundgroup.com/services.php" target="_blank">Services</a>                  </li>
<li>
                        <a href="http://eastboundgroup.com/csr.php" target="_blank">CSR</a>                    </li>
                        <li>
                        <a href="#" target="_blank">Payment Policies</a>                   </li>
<li class="menu-item-has-children">
                        <a href="http://eastboundgroup.com/contact-us.php" target="_blank">Contact</a>                   </li>
                    
                    
                    
              </ul>
            </nav>
            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
            </header>
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE -->   
      <!-- ./HEADER -->
      <!-- SLIDE -->
      <div class="clearfix"></div>
      <!-- /SLIDE --> 
      <div class="section-about margin-top-100">
         <div class="container">
            <div class="about-text text-center">
               <h1 class=" blue-heading">Eastbound Connect Series</h1>
               <h3 class="text-center black-heading1">Chapter 1 feat. Dr. A Velumani</h3>
               <br>
               <h3 class="black-heading">24 January 2020, Hotel Le Meridien Gurgaon</h3>
            </div>
         </div>
      </div>

         <div class="container">
            <!-- Blog maroonry -->
                  <div class="row">
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide1.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide2.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide3.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide4.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide5.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide6.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide7.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide8.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide9.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide10.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide11.jpg" class="center-block" width="100%" alt=""></figure><br>
<figure><img src="http://eastboundgroup.com/EBC-Picture-Gallery/Slide12.jpg" class="center-block" width="100%" alt=""></figure><br><br>

</div>
<p style="text-align:center"><font color="#0f3d54" size="5" ><a href="http://eastboundgroup.com/EBC-Photogallery2.php" target="_blank"><strong>View more images....</strong></a></font></p><br><br><br>
         </div>
		 


      <!-- FOOTER -->
      <footer class="footer">
         <div class="footer-bottom">
            <div class="container">
               <div class="row">
                  <div class="col-sm-5">
                     <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                  </div>
                  <div class="col-sm-7">
                     <ul class="footer-menu">
                        <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="http://eastboundgroup.com/csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
      <!-- ./FOOTER -->
      <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>
      <script type="text/javascript" src="js/owl.carousel.min.js"></script>
      <script type="text/javascript" src="js/chosen.jquery.min.js"></script>
      <script type="text/javascript" src="js/Modernizr.js"></script>
      <script type="text/javascript" src="js/jquery.countTo.js"></script>
      <script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
      <script type="text/javascript" src="js/jquery.easing.min.js"></script>
      <script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
      <script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
      <script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
      <script type="text/javascript" src="js/lightbox.min.js"></script>
      <script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
      <script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
      <script type="text/javascript" src="js/jquery.countdown.min.js"></script>
      <script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
      <script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
      <script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
      <script type="text/javascript" src="js/portfolio.js"></script>
      <script type="text/javascript" src="js/blog-masonry.js"></script>
      <script type="text/javascript" src="js/masonry.js"></script>
      <script type="text/javascript" src="js/custom.js"></script>
   </body>
</html>

