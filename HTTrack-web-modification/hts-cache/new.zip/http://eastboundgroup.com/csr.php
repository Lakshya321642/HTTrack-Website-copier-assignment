<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | CSR</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
 
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>

<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
        <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="section-about margin-top-100">
		<div class="container">
			<div class="about-text text-center">
			
				<h1 class=" black-heading1">Corporate Social Responsibility</h1>
               
				
				<p>At Eastbound, we contribute to various schools, NGOs and organizations. Not only do we see it as just a part of our Corporate Social Responsibility, but it is our absolute commitment to fund and work aggressively on several projects in the areas of education, wildlife conservation and social growth. Across the board, we have a proactive environmental policy, train our teams in ‘green’ thinking and to be as ‘green’ as possible. We make regular donations to the Faith Foundation, an NGO devoted to providing financial independence to destitute and widowed women and schooling to children living in the various slums of Delhi and the NCR region. The NGO that was established in September, 2003, strives towards providing the financially weak with the means to make a better livelihood. 
 </p>
			</div>
			
		</div>
	</div>
   
   
   <div class="section-portfolio2">
        <div class="bz-portfolio">
            
            <div class="bz-popup-gallery portfolio-grid portfolio-style2 pf-hover1" data-cols="5" data-layoutMode="fitRows">
                <div class="item-portfolio">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/csr/csru.png" style="width:100%;" alt="">
                        </div>
                        
                    </div>
                </div>
                <div class="item-portfolio">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/csr/2.png" style="width:100%;" alt="">
                        </div>
                        
                    </div>
                </div>
                <div class="item-portfolio">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/csr/ncsr.png" style="width:100%;" alt="">
                        </div>
                        
                    </div>
                </div>
                <div class="item-portfolio">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/csr/5.png" style="width:100%;" alt="">
                        </div>
                        
                    </div>
                </div>
                <div class="item-portfolio">
                    <div class="pf-caption">
                        <div class="pf-image">
                            <img src="images/csr/4.png" style="width:100%;" alt="">
                        </div>
                        
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>
   
   
   <div class="section-about">
		<div class="container">
			<div class="about-text text-justify">
			
				<p>We collaborate with the Faith Foundation, an NGO providing financial independence to destitute and widowed women and schooling children living in the slums of Delhi and & the NCR region. We also endeavour to work closely with the Signature Foundation, an old-age home in Kochi. This organisation works relentlessly to provide a helping hand and a better-retired life to the elderly abandoned by their families.</p>
		<p>	As a company, wildlife conservation is a cause we hold very close to our heart and we are always willing to throw our weight behind any eco-friendly crusade.  We are primary affiliates of TOFT, aunique international campaign advocating and supporting responsible tourism as a way to save the Tiger, India’s wildlife and its wilderness areas. </p>

<p>Eastbound sponsored the guide training of Sudarshan Singh Dhurvey in association with The Indian Institute of Forest Management (IIFM)Park Guide training programme. This training focuses on creating a balance between class room based theoretical teaching and field studies to nurture the remarkable skill these Park Guides already possess, having be born and brought up within forest habitats. Dhurvey is now the official guide at the Tala Zone in Kanha National Park and is gainfully employed leading groups in the Park. Kanha National Park is one of the biggest national parks in Madhya Pradesh, India, and is a Tiger Reserve in the Mandla and Balaghat districts of Madhya Pradesh, India.</p>

<p>We also endorse SOS’s Bear Rescue Village that works for the humane treatment of Indian bears.  <br> 
We sincerely believe that it is our duty to look beyond the traditionally perceived capitalist mandate of purely making a return on investment for our company’s owners or shareholders -- we want to make every effort to manage the social, environmental and economic impact of every one of our actions and make the local community a better place.</p>

			</div>
			
		</div>
	</div>
   
   
   
	
    
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                       <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>