<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Subscription Form</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
    
<div class="section-about margin-top-100">
		<div class="container">
		<h1 class="black-heading1 text-center">Subscribe our Monthly Newsletter, Fill the details below:</h1>
        </div>
</div>
    
  
    <div class="main-container" style=" background-color: #f7eedc; margin-top:10px;">
    <div class="container">
            <div class="row" align="center">
            
            <div class="col-sm-12" align="center">
                  <div class="container">
                  <h2 class="black-heading">SUBSCRIPTION FORM</h2>
                    <div class="contact-form style-2" align="center">
                        <div id="message-box-conact"></div>
                        <form method="post" action="thank-you.php">
                        <div class="form-group">
                          
                            <input id="name" type="text" value="" placeholder="Name" name="name" required>
                        </div>
                         <div class="form-group">
                          
                            <input id="email" type="text" value="" placeholder="Email"  name="email" required>
                        </div>
                         <div class="form-group">
                           
                            <input id="phone" type="text" value="" placeholder="Phone" name="phone" required>
                        </div>
                         <div class="form-group">
                           
                            <textarea id="message" rows="7" placeholder="Message" name="message" required></textarea>
                        </div>
                        <div class="text-right">
                           <input type="submit" id="btn-send-contact" value="SEND">
                        </div>`
                        </form>
                    </div>
                </div>
			</div>
			</div>
            
 
    </div></div>
    

    
    
    
    <!-- FOOTER -->

    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>