<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Destinations</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="css/style.css" />
     <script type="text/javascript" src="js/popup1.js"></script>
    <script type="text/javascript" src="js/popup2.js"></script>
</head>
<body>

<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
        <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="section-about margin-top-100">
		<div class="container">
			<div class="about-text text-center">
			
				<h1 class=" black-heading1">Destinations</h1>
               
				
				<p>Find inspiration from the experts -- at Eastbound we plan your itinerary -- from where to go, what to see, what to do, what to eat...<br>we have the best travel tips, hotels, guides, escorts and vehicles in the Indian Sub-continent and the Middle East...
 </p>
			</div>
			
		</div>
	</div>
    
    
    
    
    

       
        <div class="owl-carousel" data-nav="false" data-dots="false"  data-responsive='{"0":{"items":1},"600":{"items":2},"1000":{"items":3}}'>
            <a href="india.php">   <div class="team team-style3">
                <div class="team-image" style="width:100%; margin-right:0px;">
                    <img src="images/destinations/india.png" alt="" />                </div>
  <div class="inner">
                    <div class="team-title">
                    <h3 class="white-heading team-name">INDIA</h3>
                    </div>
                    
                </div>
            </div></a>
            
            <a href="srilanka.php">    <div class="team team-style3">
                <div class="team-image"  style="width:100%; margin-right:0px;">
                    <img src="images/destinations/srilanka.png" alt="" />                </div>
  <div class="inner">
                    <div class="team-title">
                     <h3 class="white-heading team-name">SRI LANKA</h3>
                     
                    </div>
                  
                </div>
            </div></a>
            <a href="uae.php">   <div class="team team-style3">
                <div class="team-image" style="width:100%; margin-right:0px;" >
                    <img src="images/destinations/uae.png" alt="" />                </div>
  <div class="inner">
                    <div class="team-title">
                      <h3 class="white-heading team-name">UAE</h3>
                       
                    </div>
                  
                </div>
            </div></a>
        </div>
  
    
    <div class="margin-bottom4">
       
        <div class="owl-carousel" data-nav="false" style="margin-bottom:-30px; margin-top:-31px;" data-dots="false" data-responsive='{"0":{"items":1},"600":{"items":2},"1000":{"items":3}}'>
           <a href="bhutan.php">  <div class="team team-style3">
                <div class="team-image"  style="width:100%; margin-right:0px;">
                    <img src="images/destinations/bhutan.png" alt="" />                </div>
  <div class="inner">
                    <div class="team-title">
                        <h3 class="white-heading team-name">BHUTAN</h3>
                      
                    </div>
                  
                </div>
            </div></a>
            
            <div class="team team-style3">
            <a href="">    <div class="team-image" style="width:100%; margin-right:0px;">
                    <img src="images/destinations/5.jpg"  alt="" />                </div></a>
  <div class="inner" style="background:transparent; width:100%; margin-right:0px;">
                    <div class="team-title"  >
                         <a data-border_width="0" data-boder_color="#303030" data-border_hover_color="#e1571a" data-bg="#fff" data-bghover="#e1571a" data-text_color="#303030" data-text_color_hover="#fff" href="contact-us.php#contact-us" class="button-enquiry" data-target="#myModal">HOW CAN WE HELP? <i style="color:#d3ba39;" class="fa fa-angle-right" aria-hidden="true"></i>
</a>
                      
                    </div>
                   
                </div>
            </div>
         <a href="nepal.php">    <div class="team team-style3" >
                 <div class="team-image"  style="width:100%; margin-right:0px;">
                    <img src="images/destinations/nepal.png" alt="" />                </div>
  <div class="inner">
                    <div class="team-title">
                       <h3 class="white-heading team-name">NEPAL</h3>
                      
                    </div>
                  
                </div>
            </div></a>
        </div>
        <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content my-model">
        <div class="modal-header my-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title">Please Fill Your Details.</h3>
        </div>
        <div class="modal-body">
          <form>
   			 <div class="form-group-model">
          		<input type="text" class="form-control" name="name" id="usr" placeholder="Name" required>
    		</div>
            <div class="form-group-model">
          		<input type="text" class="form-control" name="eamil" id="usr" placeholder="Email Address" required>
    		</div>
            <div class="form-group-model">
          		<input type="text" class="form-control" name="phone" id="usr" placeholder="Mobile Number" required>
    		</div>
            <input type="submit" class="btn btn-lg btn-block btn-primary my-primary" value="Submit">
  		</form>
        </div>
        
      </div>
    </div>
  </div>
    </div>
    
    
    
    
	
    
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="#" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="#" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>