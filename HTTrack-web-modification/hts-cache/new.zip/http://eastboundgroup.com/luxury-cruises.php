<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Cruises</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
        <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="section-about margin-top-100">
		<div class="container">
			<div class="about-text text-center">
			
				<h1 class=" black-heading1">Cruises & Yachts</h1>
                <p >Eastbound proudly launched its all new Super Yachts & Cruises division in 2017, with the commitment to extend the EB signature touch to this unique service. EB Cruises offers a wide range of services across the Indian sub-continent, UAE, the Maldives and Seychelles. From port handling, shore excursions, marquee events to zodiac operations, Eastbound Cruises does it all.</p>
               
               
				
				
			</div>
			
		</div>
	</div>
    
    
<style>
.color-bule{ color:#095b8a; font-weight:400; font-family: 'Raleway', sans-serif;}
.padding-50{ padding:5px 0px;}
.padding1-50{ padding:5px 50px;}
.property{padding:0px 65px 0 0; text-align:left;}
.property1{padding:0px 0px 0 50px; text-align:left;}

.divider{
    position:absolute;
    right:100%;
    top:36%;
    bottom:0;
    width:1px;
	background:#d3ba39;
	min-height:75px;
}
::-moz-selection { /* Code for Firefox */
    background: #f0d79f;
}
::selection {
    background:#f0d79f;
}
@media(max-width: 768px){
	.divider{ display:none;}
	.property{padding:0px 10px; text-align:left;}
.property1{padding:0px 10px; text-align:left;}

	}
</style>   
   
   
   
   
   <div class="section-about base5">
		<div class="container">
           <div class="row v">
                <div class="col-sm-6">
                	<article class="blog-item style5 blog-item-masonry">
                    	<div class="post-format">
                    		<figure><img alt="" src="images/luxury/luxury-2.jpg"></figure>
                    	</div>
                  </article>
                           <h4 class="padding-50 color-bule"> The EB Cruises Advantage:</h4>
                           
                           <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>A new division backed by qualified, experienced professionals at every level of Cruise operations</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4 padding-top10">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Led by a well known name in the Cruise business, with experience of over 25 years</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>An On -Ground team of experienced, energetic members</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Supported by EB offices at key port locations in India, UAE and Sri Lanka; Branch offices - Mumbai, Cochin, Chennai, Agra, Jaipur, Udaipur, Bhutan, Nepal</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Incomparable experiential Shore Excursions</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Overland tours, Cultural and Wildlife extensions</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Panel of Guest speakers, Personalities, Authors, Lecturers for Interactions or Private access</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Special interest Tours and unique Gourmet experiences led by experts, connoisseurs</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Charters of Luxury yachts, River boats</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                                       
                </div>
            	  
                <div class="col-sm-6">
                    <article class="blog-item style5 blog-item-masonry">
                        <div class="post-format">
                            <figure><img alt="" src="images/luxury/luxury-1.jpg"></figure>
                        </div>
                  </article>
                    <h4 class="color-bule">EB Cruises Services:</h4>
                    	<p>Complete support services for developing Itineraries for all vessels with respect to Port availability, Depth, Approaches, Distances, others</p>
                        
                        
                        <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Expertise in coordinating Customs, Immigration, Port Health with the Captains of the vessel</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Turnkey negotiations with Agency on Costs, Port charges, other related costs in every port of call</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Handling & Recording of all Port Agent invoices</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Work with quality Stevedores for supply of lube oil, fuel oil and fresh water in all ports</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Arrange Pier reservations for future arrivals</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Estimating Port Operation budgets for all ports</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Shore excursions at various ports of call</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Reconnaissance of new ports for future Itineraries, product and private access</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                       
                       <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Arrangement of Aircrafts, Jets and Helicopter permits</p>
					</div> 
                    
                       <div class="clearfix"></div>  
                        
                            <div class="divider"></div>
             </div>
			</div>
        </div>
	</div>
	
            <!--<div class="section-testimonial base1">
        <div class="title-page-section">
            <div class="container padding-top50">
                 <h1 class="text-center blue-heading2">	OUR CRUISE <font class="red-heading1">SPECIALIST</font></h1>
            </div>
        </div>
        <div class="container padding-top50">
            <div class="testimonials testimonials-style2">
                <div class="row">

                        <div class="avatar">
                             <img src="images/team/mohan.jpg" alt="" />
                        </div>
                      <div class="inner text-center">
                         <h6 style="color:#000;">MOHAN KRISHNAN </h6>
                            <p>In-bound Travel Whiz, Sharp Networking skills,<br> Cruise Operations Genius, Expert organizer,<br> Product Specialist & Quality Control </p>
                            
                        </div>
                </div>
            </div>
        </div>
    </div>-->

   
   
   

		

    
    
    
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                       <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>