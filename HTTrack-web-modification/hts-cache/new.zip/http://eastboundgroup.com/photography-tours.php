<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Photography Tours</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
    <link href="css/jquery.littlelightbox.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/photography-slider.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
 
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body> 
<aside id="sticky-social">
    <ul>
        <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
        <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
        <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
      <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="margin-top-100 margin-top-50">
		<div class="container">
			<div class="about-text text-center">
			
				<p class="black-heading1" style="font-weight:200; font-size:36px">Photography Tours</p>
               
			</div>
			
		</div>
	</div>
    

        <div class="container margin-top-30">
            <div class="col-sm-12 col-md-12 main-content pt-slider-bg">
                <div class="w3-content w3-display-container">

<a class="w3-btn-floating w3-hover-dark-grey w3-display-left" onClick="plusDivs(-1)">&#10094;</a>
<a class="w3-btn-floating w3-hover-dark-grey w3-display-right" onClick="plusDivs(1)">&#10095;</a>

<div class="w3-display-container mySlides">
  <img src="images/photography-tours/slide-1.jpg" style="width:100%">
  <div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
    Our guests are busy clicking the Elephant on his daily round 
  </div>
</div>

<div class="w3-display-container mySlides">
  <img src="images/photography-tours/slide-2.jpg" style="width:100%">
  <div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
    Young monks walk down to the Holy River Ganges to perform the Morning Prayer 
  </div>
</div>




<div class="w3-display-container mySlides">
  <img src="images/photography-tours/slide-3.jpg" style="width:100%">
 <div class="w3-display-bottomleft w3-large w3-container w3-padding-16 w3-black">
   Our guests are served with breakfast at a Buddhist monastery in Leh, Ladakh. 
  </div></div>

</div>
            </div>
            
        </div>
        
        
      <script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel,4000); // Change image every 2 seconds
}
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  x[slideIndex-1].style.display = "block"; 
   
}
</script>

   
   
   
   
   
   
   <div class="section-about">
		<div class="container">
            <div class="col-sm-12 col-md-12 main-content">
                <div class="blog-single">
                    
                    
                    
                    

                    <div class="related-posts">
                       
                        <div class="list-related-posts">
                            <article class="blog-item row">
                                <div class="col-sm-4">
                                    <div class="post-format">
                                      <a class="lightbox thumbnail" href="images/photography-tours/parrot.jpg" data-littlelightbox-group="gallery" title="Shot during a village safari near Udaipur, Rajasthan.">
<img src="images/photography-tours/parrot.jpg" style="margin-top:11px;" alt="Shot during a village safari near Udaipur, Rajasthan." /></a>                                    </div>
                              </div>
                                <div class="col-sm-8">
                                    <div class="content-post">
                                     <p><font class="yellow-color"><strong>Eastbound Photography Tours</strong></font> is the experiential photography division of the Eastbound Group.</p>

<p>We create photography journeys that are simply incomparable. Led by our extremely well known and illustrious photographers, and accompanied by our highly accomplished talent pool of escorts, naturalists and field guides who are experts on India and sub-continent, we bring an unparalleled Vision, Experience, Intensity and Art to the experience.</p>

<p>Very grounded and very close to the pulse of the region; the photography tours and one-on-one lessons with the photographers leading the group, bring forth wonderfully evocative photos, in locations and moments that define standards for that once-in-a – lifetime opportunity you simply dream of.</p>
     <p>We offer a wide variety of photographic safaris that are suitable for both amateur and professional photographers alike. We work with several leading photographers and tour operators especially in the UK, Europe and Australia.</p>

<p>All this is backed by Eastbound’s superior buying power, vehicles, room rates, office network, etc.</p>

<p>Planned by a photographer, for photographers, the Eastbound Photo Tours are the absolute pinnacle in excellence on a journey of discovery for the soul.</p>

</p>

                                    </div>
                                  
                                </div>
                            </article>
                           
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
	</div>
   
   
   
   
   
   
   
   
   
   
   <div class="base1" style="height:300px;"></div>
   <div class="section-about" style="margin-top:-300px;">
		<div class="container">
            <div class="col-sm-12 col-md-12 main-content">
                <div class="blog-single">
                    
                    
                    
                    

                    <div class="related-posts">
                       
                        <div class="list-related-posts">
                            <article class="blog-item row">
                                <div class="col-sm-4">
                                    <div class="post-format">
                                          <a class="lightbox thumbnail" href="images/photography-tours/abhishek.jpg" data-littlelightbox-group="gallery" title="Shot during the Hornbill festival in Nagaland, North-East of India.">
<img src="images/photography-tours/abhishek.jpg"  alt="Shot during the Hornbill festival in Nagaland, North-East of India." /></a>                                    </div>
                              </div>
                                <div class="col-sm-8">
                                    <div class="content-post">
                                      <p style="margin-top:-11px;">  <font class="yellow-color"><strong>Abhishek Hajela</strong></font> is a ‘Nikon International Photography Award Winner’, National Photojournalist, Blogger and a well-experienced travel escort based in New Delhi. He leads and curates our Photography Tours and specialized experiential travel itineraries across India, Bhutan, Nepal and Sri Lanka’s culture, festivals, people, villages; and the sheer plethora of experiences that the region offers.</p>

<p>He is associated with Olympus, Manfrotto and Data Color and leads focused Photography Tours in India and abroad specifically designed for photographers; both amateurs and professionals. He is also actively involved and the front-runner for their promotional activities and integrated marketing campaigns in India. </p>

<p>He has over eight years of experience accompanying and escorting High-End private journeys and groups from markets like USA, UK, and Australia.</p>

<p>His extensive travels, combined with his ample product knowledge and deep understanding of travelers, dovetails perfectly with a photographer’s perspective and keen eye. </p>

<p>His images are regularly featured in Outdoor Photographer, Hindustan Times; Jet Airways in-flight magazine, Mail Today, HT Mint Lounge, Air India Magazine, Asia Spa magazine, California Bride Magazine to name a few.</p>
<p>The Ministry of Tourism also selects a number of his travel images for the Incredible India! Campaign on an on-going basis. </p>

                                    </div>
                                  
                                </div>
                            </article>
                           
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
	</div>
    
     <div class="base1" style="height:300px;"></div>
   <div id="pt-page1">
   <div class="section-about1" style="margin-top:-300px;">
		<div class="container">
	<h1 class="text-center black-heading1">On Our Photo Trips</h1>
<div class="row">

<div class="col-lg-4">
<a class="lightbox thumbnail" href="images/photography-tours/1-large.jpg" data-littlelightbox-group="gallery" title="Busy guests during a Photo Walk in Jaipur! <br> © Eastbound Group">
<img src="images/photography-tours/1.jpg" alt="Flying is life" /></a>
</div>

<div class="col-lg-4">
<a class="lightbox thumbnail" href="images/photography-tours/2-large.jpg" data-littlelightbox-group="gallery" title=" Close up of a priest during the annual festival of colors ‘Holi’ in North India <br> © Eastbound Group">
<img src="images/photography-tours/2.jpg" alt="Flying is life" /></a>
</div>

	<div class="col-lg-4">
<a class="lightbox thumbnail" href="images/photography-tours/3-large.jpg" data-littlelightbox-group="gallery" title="Children getting dressed for a drama, during the festival of Dusshera in Varanasi! <br> © Eastbound Group">
<img src="images/photography-tours/3.jpg" alt="Flying is life" /></a>
</div>

<div class="col-lg-4">
<a class="lightbox thumbnail" href="images/photography-tours/4-large.jpg" data-littlelightbox-group="gallery" title="Colorful procession during the annual Bikaner festival, Rajasthan  <br> © Eastbound Group">
<img src="images/photography-tours/4.jpg" alt="Flying is life" /></a>
</div>

<div class="col-lg-4">
<a class="lightbox thumbnail" href="images/photography-tours/5-large.jpg" data-littlelightbox-group="gallery" title="John is busy showing his images to the locals, a common site during our trips <br> © Eastbound Group">
<img src="images/photography-tours/5.jpg" alt="Flying is life" /></a>
</div>

<div class="col-lg-4">
<a class="lightbox thumbnail" href="images/photography-tours/6-large.jpg" data-littlelightbox-group="gallery" title="TJ hanging out during the Tuk-Tuk ride to get his best shot! <br> © Eastbound Group">
<img src="images/photography-tours/6.jpg" alt="Flying is life" /></a>
</div>

</div>
<center><a href="photo-gallery.php" class="button primary medium radius">GO TO PHOTO GALLERY</a></center>
</div>
	</div></div>
   
   
   <script src="js/photography-tours.js"></script>
<script src="js/jquery.littlelightbox.js"></script>
<script>
$('.lightbox').littleLightBox();
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
   
   
   
	
    
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>