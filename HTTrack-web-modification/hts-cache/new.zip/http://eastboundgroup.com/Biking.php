<!DOCTYPE HTML>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="UTF-8">
    <meta name="author" content="ngocthang.ict" />
    <title>Eastbound Group | Biking</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/chosen.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon-enterprise.css" />
    <link rel="stylesheet" type="text/css" href="css/streamline-icon.css" />
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/easy-responsive-tabs.css" />
    <link rel="stylesheet" type="text/css" href="css/lightbox.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flexslider.css" />
    <link rel="stylesheet" type="text/css" href="css/YTPlayer.css" />
    <link href="css/jquery.littlelightbox.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/photography-slider.css" />

    <link href='https://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Herr+Von+Muellerhoff' rel='stylesheet' type='text/css'>
 
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body> 
<aside id="sticky-social">
    <ul>
       <li><a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" class="entypo-facebook" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
      <li><a href="https://www.instagram.com/eastbound_official/" class="entypo-gplus" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
      <li><a href="https://www.linkedin.com/company/east-bound-official/" class="entypo-linkedin" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
  </ul>
</aside>
    <!-- HEADER -->
      <!--<header class="header header-fullwidth style3 base" >-->
    <header class="header header-fullwidth style3" >    
        <div class="popup-search">
            <div class="popup-search-form">
                <form>
                    <input class="input-search" type="text" placeholder="ENTER YOUR KEYWORDS..." />
                </form>
                <span title="Close" class="close-popup"><i class="fa fa-times"></i></span>
            </div>
        </div>
       
        <div class="header-container">
            <div class="logo">
            <a href="index.php"><img src="http://eastboundgroup.com/images/Logo-combined.png" alt="" / class="headlogo"></a><!--<a href="http://eastboundgroup.com/corona.php" target="_blank" style="color: #d7c14e; padding-top: 21.5px !important;" class="bz-main-mennu"><img src="http://eastboundgroup.com/images/Corona-update.gif" alt="" />COVID-19 UPDATES</a>-->
            </div>
            <div class="bz-main-mennu">
            <nav class="main-menu">
                <ul>
                    <li class="current-menu-item">
                        <a class="current-active" href="index.php">Home</a>
					</li>

                    <li class="menu-item-has-children">
                        <a  href="#">Our Company</a>
                        <ul class="sub-menu">
                            <li>
                                <a href="about-us.php">About Us</a>
                            </li>
							
							<li>
                                <a href="our-group.php">Group Companies</a>
                            </li>
                            
                            <li>
                                <a href="team.php">Team</a>
                                </li>
                                
                                <li>
                                <a href="contact-us.php">Our Presence</a>
                                </li>

                                <!--<li>
                                <a href="photo-gallery.php">Photo Gallery</a> 
                                </li>-->
                        </ul>
					</li>

                    <li>
                      <a href="destinations.php">Destinations</a> 
					</li>
                               <li>
                        <a href="services.php">Services</a>
                        </li>
                             <li>
                        <a href="csr.php">CSR</a>
                        </li>
					
					<li>
                    <a href="http://eastboundgroup.com/eastnews.php">Newsletter</a> 
                    </li>

                    <li class="menu-item-has-children">
                        <a href="#" target="_blank">Payment Policies</a>                   </li>

                            <li class="menu-item-has-children">
                        <a href="contact-us.php">Contact</a>
                        </li>
              </ul>

            </nav>

            <a href="#" class="mobile-navigation"><i class="fa fa-bars"></i></a>
        </div>
        </div>
    </header>  
  
    <!-- ./HEADER -->
    <!-- SLIDE -->
    
    <div class="clearfix"></div>
    <!-- /SLIDE --> 

	<div class="margin-top-100 margin-top-50">
		<div class="container">
			<div class="about-text text-center">
			
				<p class="black-heading1" style="font-weight:200; font-size:36px">Biking</p>
               
			</div>
			
		</div>
	</div>
    

        <div class="container margin-top-30">
            <div class="col-sm-12 col-md-12 main-content pt-slider-bg">
                <div class="w3-content w3-display-container">

<a class="w3-btn-floating w3-hover-dark-grey w3-display-left" onClick="plusDivs(-1)">&#10094;</a>
<a class="w3-btn-floating w3-hover-dark-grey w3-display-right" onClick="plusDivs(1)">&#10095;</a>

<div class="w3-display-container mySlides">
  <img src="images/photography-tours/biking.jpg" style="width:100%">

</div>

<div class="w3-display-container mySlides">
  <img src="images/photography-tours/biking2.jpg" style="width:100%">

</div>

</div>
            </div>
            
        </div>
        
        
      <script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel,4000); // Change image every 2 seconds
}
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";
  }
  x[slideIndex-1].style.display = "block"; 
   
}
</script>

   
   
   
   
   
   
   <div class="section-about">
		<div class="container">
            <div class="col-sm-12 col-md-12 main-content">
                <div class="blog-single">
                    
                    <div class="related-posts">
                       
                        <div class="list-related-posts">
                            <article class="blog-item row">
                                <div class="col-sm-4">
                                    <div class="post-format">
                                     <img src="images/photography-tours/biking3.jpg" style="margin-top:11px;" alt="Shot during a village safari near Udaipur, Rajasthan." /></a>                                    </div>
                              </div>
                                <div class="col-sm-8">
                                    <div class="content-post">
                                     <p><font class="yellow-color"><strong>We believe Motorcycles</strong></font> are magic. It’s fire, air and earth mated to perfection!</p>
									 <p>There are only a few things in life that can be as rewarding and as thrilling as thumping along an eddying river on a motorcycle sashaying your way up the serpentine roads of the Himalayas.</p><br>

<h5>Highlights:</h5>

<div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Ride with the trill of riding on precarious roads with deep valleys on one side and mountain slopes on the other.</p>
					</div> 
                    
                       <div class="clearfix"></div>   
                    
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Visit an organic farm in Nogli for lunch, where dishes are prepared using local produce. </p>
					</div>       
                     <div class="clearfix"></div>
					 
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Visit the village of Chitkul, which happens to be the last inhabited village at the Indo-China border.</p>
					</div>
                     <div class="clearfix"></div> 
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Ride while enjoying the contrast of the clear blue skies against this rustic mountains is stark yet pleasing.</p>
					</div>
                     <div class="clearfix"></div> 
                    
                    <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Ride out to the village of Dhangkar, and spend some time with Lamas sipping some delicious local tea at the Dhankar monastery which is perched atop a cliff overlooking the confluence of Spiti and Pin rivers.</p>
					</div>
                     <div class="clearfix"></div> 
					                     <div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Ride up to Komic, which is touted as the highest village in the whole of Asia which is connected by a motorable road. </p>
					</div>
                     <div class="clearfix"></div>
					<div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>The ride to Losar is worth it! The night skies here are magical and is arguably one of the best places to view and photograph our very own galaxy, The Milky Way!</p>
					</div>
                     <div class="clearfix"></div>
					<div class="bz-element-icon element-icon-4">
						<span class="icon"><img src="images/about-us/about-icon.png"/></span>
						
						<p>Ride on the road between Losar to Gramphu - where one joins the highway is an adventurer's dream, multiple water streams to cross, riding on washboards, dried up riverbeds with jagged stones and boulders strewn all over the path. This road puts the mettle of the most seasoned rider to test but is worth all the trouble taken as it rewards you with some really stunning landscape.</p>
					</div>
                     <div class="clearfix"></div>					 

                                    </div>
                                  
                                </div>
                            </article>
                           
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
	</div>
   
  <script src="js/photography-tours.js"></script>
<script src="js/jquery.littlelightbox.js"></script>
<script>
$('.lightbox').littleLightBox();
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
   
    <!-- FOOTER -->
    <footer class="footer">
        
         
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="footer-coppyright footer-social">© Eastbound - Incomparable Luxury Travel Experiences</div>
                    </div>
                    <div class="col-sm-7">
                        <ul class="footer-menu">
                            <a href="https://www.facebook.com/eastboundtravels/?fref=ts&ref=br_tf" target="_blank"><i class="fa fa-facebook footer-social"></i></a>
                        <a href="https://plus.google.com/100809616177764073302?hl=en" target="_blank"><i class="fa fa-google-plus footer-social" aria-hidden="true"></i></a>
                        <a href="csr.php" target="_blank"><i class="fa fa-heart footer-social" aria-hidden="true"></i></a>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scroll_top" title="Scroll to Top"><i class="fa fa-arrow-up"></i></a>
    <!-- ./FOOTER -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="js/Modernizr.js"></script>
<script type="text/javascript" src="js/jquery.countTo.js"></script>
<script type="text/javascript" src="js/jquery.parallax-1.1.3.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/jquery.debouncedresize.js"></script>
<script type="text/javascript" src="js/easyResponsiveTabs.js"></script>
<script type="text/javascript" src="js/lightbox.min.js"></script>
<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="js/jquery.mb.YTPlayer.js"></script>
<script type="text/javascript" src="js/jquery.countdown.min.js"></script>
<script type="text/javascript" src="js/isotope.pkgd.min.js"></script>
<script type="text/javascript" src="js/masonry.pkgd.min.js"></script>
<script type="text/javascript" src="js/imagesloaded.pkgd.min.js"></script>
<script type="text/javascript" src="js/portfolio.js"></script>
<script type="text/javascript" src="js/blog-masonry.js"></script>
<script type="text/javascript" src="js/masonry.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
</body>

</html>